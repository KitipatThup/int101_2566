package work04;

import work04.Person;

public class BankAccount {

    private int number;
    private Person owner;
    private double balance;

    public BankAccount(int number, Person owner) {
        this.number = number;
        this.owner = owner;
        this.balance = 0.0;
    }

    public Person getOwner() {
        return owner;
    }

    public double getBalance() {
        return balance;
    }

    public double deposit(double amount) {
        return this.balance = balance + amount;
    }

    public double withdraw(double amount) {
        if (this.balance < amount) {
            System.out.println("You can not withdraw.");
        }
        return this.balance = balance - amount;
    }

    public static void transfer(double amount, BankAccount account1, BankAccount account2) {
        if (account1.balance < amount) {
            System.out.println("You can not transfer.");
        } else {
            account1.withdraw(amount);
            account2.deposit(amount);
        }
    }

    @Override
    public String toString() {
        return "BankAccount{" + "id = " + number + "}";
    }
}
